<?php

namespace App\Providers;


class ModelObserverServiceProvider extends EventServiceProvider
{
    public function boot()
    {
        parent::boot();
    }
}
