<?php

namespace App\Constants;

Class ConstantsConstant {
      const Gender = [
                                    'Transgender',
                            'Female',
                            'Male',
                            ];

    }
